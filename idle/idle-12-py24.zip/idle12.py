#!/usr/bin/env python

from idlelib12 import PyShell

PyShell.main()
